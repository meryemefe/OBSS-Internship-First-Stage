package com.meryemefe;

public class Bus {
    private Destination destination;
    private Passenger[] passengers;
    private int capacity;
    private int numOfPassengers = 0;

    public Bus(int capacity) {
        this.capacity = capacity;
        this.passengers = new Passenger[capacity];
    }

    public Bus(Destination destination, int capacity) {
        this.destination = destination;
        this.capacity = capacity;
        this.passengers = new Passenger[capacity];
    }

    /* This method takes the passenger and tries to insert her/him to the bus.
    * It prints warning message if bus is full or destinations don't match
    */
    public void insertPassenger(Passenger passenger){
        if( numOfPassengers < capacity && this.destination == passenger.getDestination()){
            passengers[numOfPassengers] = passenger;
            numOfPassengers++;
            System.out.println("Passenger " + passenger.getName() + " is inserted.");
        } else if( this.destination != passenger.getDestination()){
            System.out.println("Passenger " + passenger.getName() + " couldn't be inserted. Destinations do not match.");
        } else {
            System.out.println("Passenger " + passenger.getName() + " couldn't be inserted. Bus is full.");
        }
    }

    public Destination getDestination() {
        return destination;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setDestination(Destination destination) {
        this.destination = destination;
    }

    public Passenger[] getPassengers() {
        return passengers;
    }

    public void setPassengers(Passenger[] passengers) {
        this.passengers = passengers;
    }
}
