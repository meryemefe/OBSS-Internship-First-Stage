package com.meryemefe;

public enum Destination {
    ISTANBUL, ADANA, ANKARA, KAYSERI
}
