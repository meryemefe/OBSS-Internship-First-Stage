package com.meryemefe;

public class Main {

    public static void main(String[] args) {

        // Initialize the bus and passengers.
        Bus b1 = new Bus(Destination.ANKARA, 3);

        Passenger p1 = new Passenger("Meryem", Destination.ANKARA);
        Passenger p2 = new Passenger("Efe", Destination.ISTANBUL);
        Passenger p3 = new Passenger("Ayse", Destination.ANKARA);
        Passenger p4 = new Passenger("Hamza", Destination.ANKARA);
        Passenger p5 = new Passenger("Elif", Destination.KAYSERI);
        Passenger p6 = new Passenger("Sinan", Destination.ANKARA);

        // Try to insert passengers to the bus
        b1.insertPassenger(p1);
        b1.insertPassenger(p2);
        b1.insertPassenger(p3);
        b1.insertPassenger(p4);
        b1.insertPassenger(p5);
        b1.insertPassenger(p6);
    }
}
