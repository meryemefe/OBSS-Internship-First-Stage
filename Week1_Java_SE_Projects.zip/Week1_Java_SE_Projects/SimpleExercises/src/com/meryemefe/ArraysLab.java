package com.meryemefe;

public class ArraysLab {

    public static int[] reverseArray(int[] arr) {

        int[] reverseArr = new int[arr.length];
        for (int i = 0; i < reverseArr.length; i++)
            reverseArr[i] = arr[arr.length - i - 1];
        return reverseArr;
    }

    public static void printDoubleArray(int[][] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++)
                System.out.print(arr[i][j] + "\t");
            System.out.println();
        }
    }

    public static void main(String[] args) {

        System.out.println("PART 1: This part prints reverse of the array.");

        // Initialize array
        int[] arr = new int[5];
        for (int i = 0; i < arr.length; i++)
            arr[i] = i * 2;

        // Print the original array
        System.out.print("Original Array: ");
        for (int i : arr)
            System.out.print(i + " ");

        // Call reverse array method and print reverse
        int[] reverseArr = reverseArray(arr);
        System.out.print("\nReverse Array: ");
        for (int i : reverseArr)
            System.out.print(i + " ");
        System.out.println("\n");


        // Second Part
        System.out.println("PART 2: This part prints the double array.");
        int[][] locations = new int[3][4];
        int count = 0;

        for (int i = 0; i < locations.length; i++) {
            for (int j = 0; j < locations[i].length; j++)
                locations[i][j] = ++count;
        }
        System.out.println("DOUBLE ARRAY");
        printDoubleArray(locations);

    }
}
