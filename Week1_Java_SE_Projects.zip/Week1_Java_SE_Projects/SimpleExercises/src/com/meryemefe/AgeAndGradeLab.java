package com.meryemefe;

import java.util.Scanner;

public class AgeAndGradeLab {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        /*
         First Part:
         This part asks users to enter their ages and decides if they are young or old.
         */
        System.out.println("FIRST PART");
        int age;
        do {
            System.out.println("Please, enter your age (To exit, enter -1): ");
            age = scan.nextInt();

            if( age == -1)
                System.out.println("Goodbye!");
            else if (age < 0)
                System.out.println("Invalid input!");
            else if (age < 30)
                System.out.println("You are young :) ");
            else if (age < 45)
                System.out.println("You are middle-aged. ");
            else
                System.out.println("You are old.");
        } while (age != -1);

        /*
         Second Part:
         This part asks user to enter numbers and prints average of the input numbers.
         */
        System.out.println("SECOND PART");

        double grade;
        double totalGrades = 0;
        int numOfGrades = 0;

        System.out.println("Please, enter grades (To exit, enter 101): ");
        grade = scan.nextDouble();
        while (grade != 101) {
            numOfGrades++;
            totalGrades += grade;
            grade = scan.nextInt();
        }

        // Check whether input size is 0 because of division by zero error
        if (numOfGrades != 0) {
            System.out.println("Total grades: " + totalGrades);
            System.out.println("Number of grades: " + numOfGrades);
            System.out.println("Average grade is " + (totalGrades / numOfGrades));
        } else {
            System.out.println("Invalid input size!");
        }
    }
}
