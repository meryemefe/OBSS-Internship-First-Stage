package com.meryemefe;

import java.util.Scanner;

public class NumberGuessGame {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        // Generate a random integer between 0 and 50
        int number = (int) (Math.random() * 50);

        System.out.println("Please, predict the number:");

        // User have 5 trials. Ask them their predictions 5 times.
        boolean isFound = false;
        for (int i = 0; i < 5 && !isFound; i++) {
            int guess = scan.nextInt();
            if (guess < number) {
                System.out.println("Incorrext estimation! Try larger numbers.");
            } else if (guess > number) {
                System.out.println("Incorrext estimation! Try smaller numbers.");
            } else {
                System.out.println("Weldone, you corrextly predicted in " + (i + 1) + "th estimation!");
                isFound = true;
            }
        }

        // If user is not successfull, show the secret number
        if (!isFound)
            System.out.println("You failed! The secret number is " + number + ".");
    }
}
