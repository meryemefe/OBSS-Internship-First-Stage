package com.meryemefe;

import java.util.Arrays;

public class StreamExercise {
    public static void main(String[] args) {

        // Initialize a list of first 10 positive integers
        int[] list = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        // Calculate sum of the number larger than 5 (or equal to 5) by multiplying 3
        int sum = Arrays.stream(list).filter(e -> e >= 5).map(e -> e * 3).sum();
        System.out.println(sum);
    }
}
