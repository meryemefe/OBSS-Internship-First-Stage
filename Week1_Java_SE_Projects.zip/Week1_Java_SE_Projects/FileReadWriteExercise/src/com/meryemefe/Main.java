package com.meryemefe;

import java.io.*;

public class Main {

    public static void main(String[] args) {

        // Write to a file
        try {
            FileWriter fw = new FileWriter("resources/readme.txt");
            fw.write("Hello Meryem");
            fw.close();
        } catch( Exception e) {
            e.printStackTrace();
        }

        // Read from a file
        try{
            BufferedReader bis = new BufferedReader( new FileReader("resources/readme.txt") );
            System.out.println( bis.readLine());
            bis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
