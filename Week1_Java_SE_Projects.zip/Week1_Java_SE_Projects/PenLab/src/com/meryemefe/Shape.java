package com.meryemefe;

public class Shape {
    private String color;

    public Shape(String color) {
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double drawShape() {
        return 0;
    }

    @Override
    public boolean equals( Object o){
        if( o instanceof Shape )
            return this.color.equals(((Shape) o).getColor());
        return false;
    }

}
