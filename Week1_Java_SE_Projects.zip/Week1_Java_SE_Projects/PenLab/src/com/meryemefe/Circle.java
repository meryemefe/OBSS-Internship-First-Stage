package com.meryemefe;

public class Circle extends Shape {
    private int radius;

    public Circle(int radius, String color) {
        super(color);
        this.radius = radius;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public String getColor() {
        return super.getColor();
    }

    public void setColor(String color) {
        super.setColor(color);
    }

    public double getArea() {
        return Math.PI * radius * radius;
    }

    @Override
    public double drawShape() {
        return Math.PI * radius * radius;
    }

    @Override
    public String toString(){
        return "CIRCLE Radius: " + radius + ", Color: " + super.getColor();
    }

    @Override
    public boolean equals( Object o){
        if( o instanceof Circle )
            return super.equals(o) && this.radius == ((Circle) o).getRadius();
        return false;
    }
}
