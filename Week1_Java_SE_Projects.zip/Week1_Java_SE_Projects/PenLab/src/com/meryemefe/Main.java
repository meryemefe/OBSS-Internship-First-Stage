package com.meryemefe;

public class Main {

    public static void main(String[] args) {

        // Initialize a pen, a circle, and a rectangle
        Pen pen = new Pen();
        Circle c = new Circle(4, "RED");
        Rectangle r = new Rectangle(3, 5, "GRAY");

        // Prints initial attributes of circle and rectangle.
        System.out.println("Initially, you have a circle and a rectangle:\n" + c + "\n" + r);

        // Play with the methods of pen.
        // Draw circle & rectangle, return their areas.
        double circleArea = pen.drawShape(c);
        System.out.println("\nYou drew a circle whose area is " + circleArea + ".");

        double recArea = pen.drawShape(r);
        System.out.println("You drew a rectangle whose area is " + recArea + ".");

        // Change the color of the shapes
        pen.changeColorShape("BLUE", c);
        pen.changeColorShape("BLACK", r);
        System.out.println("\nYou changed the color of the circle and rectangle. New attributes are:\n" + c + "\n" + r + "\n");

        // Try if two circles or rectangles equals
        Circle c2 = new Circle(4, "BLUE");
        Rectangle r2 = new Rectangle(8, 5, "BLACK");

        if( c.equals(c2) )
            System.out.println( "Circle 1 and 2 equals." );
        else
            System.out.println( "Circle 1 and 2 don't equal." );

        if( r.equals(r2) )
            System.out.println( "Rectangle 1 and 2 equals." );
        else
            System.out.println( "Rectangle 1 and 2 don't equal." );

    }
}
