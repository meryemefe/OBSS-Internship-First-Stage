package com.meryemefe;

public class Rectangle extends Shape {
    private int width;
    private int height;

    public Rectangle(int width, int height, String color) {
        super(color);
        this.width = width;
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public String getColor() {
        return super.getColor();
    }

    public void setColor(String color) {
        super.setColor(color);
    }

    public int getArea() {
        return width * height;
    }

    @Override
    public double drawShape() {
        return width * height;
    }

    @Override
    public String toString(){
        return "RECTANGLE Width: " + width + ", Height: " + height + ", Color: " + super.getColor();
    }

    @Override
    public boolean equals( Object o){
        if( o instanceof Rectangle )
            return super.equals(o) && this.width == ((Rectangle) o).getWidth() && this.height == ((Rectangle) o).getHeight();
        return false;
    }
}
