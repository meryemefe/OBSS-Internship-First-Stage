package com.meryemefe;

public class Pen {

    public double drawShape( Shape s){

        // This is the first approach.
        // Using polymorphism, Rectangle and Circle classes overrides drawShape method of Shape superclass.
        return s.drawShape();

        /*
        // This is the second approach.
        // Checking if Shape object is instance of Circle or Rectangle class, call appropriate method by using casting
        // Here, similarly to the first approach, we can add getArea() method to Shape class and override it in subclasses.
        if( s instanceof Rectangle )
            return (double) ((Rectangle) s).getArea();
        else
            return ((Circle)s).getArea();
        */
    }

    public void changeColorShape( String color, Shape s){
        s.setColor(color);
    }

    /*
    // These parts is done in the first Pen Lab.
    // After inheritance and polymorphism subjects, this approach is improved.
    public int drawRectangle(Rectangle r) {
        return r.getArea();
    }

    public double drawCircle(Circle c) {
        return c.getArea();
    }

    public void changeColorRectangle(String color, Rectangle r) {
        r.setColor(color);
    }

    public void changeColorCircle(String color, Circle c) {
        c.setColor(color);
    }
    */
}