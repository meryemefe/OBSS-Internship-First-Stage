package com.meryemefe;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Main {

    public static void main(String[] args) {

        // Initialize a User object
        User meryem = new User( "Meryem", 22);

        // Serialization
        try {
            // Writing the object to a file
            FileOutputStream fos = new FileOutputStream("resource/object.ser");
            ObjectOutputStream ous = new ObjectOutputStream(fos);

            System.out.println("User has been serialized.");

            ous.writeObject(meryem);

            fos.close();
            ous.close();

        } catch (Exception e){
            e.printStackTrace();
        }

        // Deserialization
        try
        {
            // Reading the object from a file
            FileInputStream fis = new FileInputStream("resource/object.ser");
            ObjectInputStream ois = new ObjectInputStream(fis);

            // Method for deserialization of object
            User user = (User)ois.readObject();

            System.out.println("User has been deserialized.");
            System.out.println("User's name is " + user.getName() + ", age is " + user.getAge() +".");

            fis.close();
            ois.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

    }
}
