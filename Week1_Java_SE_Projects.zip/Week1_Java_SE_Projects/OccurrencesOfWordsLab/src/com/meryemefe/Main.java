package com.meryemefe;

import java.util.*;

public class Main {

    /*
     * This method takesString and returns words with their number of occurrences
     * @param String
     * @returns TreeMap
     * */
    public static TreeMap<String, Integer> words(String str) {

        // Initialize TreeMap
        TreeMap<String, Integer> map = new TreeMap<>();

        // Split string according to spaces
        String[] splitedStr = str.split(" ");

        // Put words to the set
        for (int i = 0; i < splitedStr.length; i++) {
            map.put(splitedStr[i], map.getOrDefault(splitedStr[i], 0) + 1);

            /*
            // This is second approach using "put" and "replace" methods.
            // If map already contains that words, just replace their value,
            // otherwise, put it to map with value 1
            if( !map.containsKey( splitedStr[i] ) )
                map.put( splitedStr[i], 1);
            else
                map.replace( splitedStr[i], map.get(splitedStr[i]) + 1);
             */
        }
        return map;
    }

    public static void main(String[] args) {

        // Initialize string and map
        String str = "read book read newspaper write book play guitar play volleyball play basketball";
        TreeMap<String, Integer> wordMap = words(str);

        // Display all the entries with values
        System.out.println("MAP ENTRIES SORTED BY KEY");
        for (Map.Entry<String, Integer> entry : wordMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        // In order to sort entries by value,
        // define new Comparator and override compare method
        // In compare method, consider keys if values equal
        TreeSet<Map.Entry<String, Integer>> sortedSet = new TreeSet<>(new Comparator<Map.Entry<String, Integer>>(){
            @Override
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                if( o1.getValue().compareTo(o2.getValue()) == 0 )
                    return o1.getKey().compareTo(o2.getKey());
                else
                    return o1.getValue().compareTo(o2.getValue());
            }
        });

        // Put words to the set
        for (Map.Entry<String, Integer> entry : wordMap.entrySet()) {
            sortedSet.add( new AbstractMap.SimpleEntry<>( entry.getKey(), entry.getValue() ) );
        }

        // Display all the entries with values of the map which is sorted by values
        System.out.println("\nMAP ENTRIES SORTED BY VALUE");
        for (Map.Entry<String, Integer> entry : sortedSet) {
            System.out.println( entry.getValue() + ": " + entry.getKey() );
        }
    }
}
