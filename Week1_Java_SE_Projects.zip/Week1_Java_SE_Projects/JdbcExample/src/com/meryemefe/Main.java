package com.meryemefe;

import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    static final String url = "jdbc:mysql://localhost:3306/jdbc_schema?serverTimezone=UTC";
    static final String user = "root";
    static final String password = "meryemefe243";

    public static void main(String[] args) {

        // Initialize a list of customers
        ArrayList<Customer> customerList = new ArrayList<>(7);
        customerList.add( new Customer(1, "Meryem", true) );
        customerList.add( new Customer(2, "Efe", false) );
        customerList.add( new Customer(3, "Hamza", true) );
        customerList.add( new Customer(4, "Yuksel", false) );
        customerList.add( new Customer(5, "Ege", true) );
        customerList.add( new Customer(6, "Tuna", false) );
        customerList.add( new Customer(7, "Sina", false) );


        // Using "try with resources" create customers table in database if not exist
        // Than, add the customers' information if the values has not been added
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            try( Connection connection = DriverManager.getConnection( url, user, password) ){
                System.out.println("Connection is successful!");
                String query = "create table if not exists customers (id int not null, name varchar(40), active tinyint(1), primary key(id) )";
                try( PreparedStatement pstmt = connection.prepareStatement(query) ){
                    // Create a new table named "Customers"
                    pstmt.executeUpdate();

                    // Insert some values to the table
                    for (Customer customer : customerList) {
                        pstmt.executeUpdate("insert ignore into customers values (" + customer.getId() + ",'" + customer.getName() + "'," + customer.isActive() + ")" );
                    }

                    // Read data
                    System.out.println("\nCustomer List:");
                    try (ResultSet rs = pstmt.executeQuery("select * from customers");) {
                        while(rs.next()) {
                            Customer customer = new Customer(rs.getInt("id"), rs.getString("name"), rs.getInt("active")==1?true:false );
                            System.out.println(customer);
                        }
                    }

                    System.out.println( "\nStatements are successfully executed!");
                }
            }
        } catch(ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
