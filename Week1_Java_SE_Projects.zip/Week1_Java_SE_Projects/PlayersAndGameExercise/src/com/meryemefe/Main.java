package com.meryemefe;

import java.util.HashSet;

public class Main {

    public static void main(String[] args) {

        // Initialize players
        Player p1 = new Player("p1");
        Player p2 = new Player("p2");
        Player p3 = new Player("p3");
        Player p4 = new Player("p4");
        Player p5 = new Player("p5");

        // Add players to the Game
        Game.addPlayer(p1);
        Game.addPlayer(p2);
        Game.addPlayer(p3);
        Game.addPlayer(p4);
        Game.addPlayer(p5);
        System.out.println( "Number of players: " + Game.numberOfPlayers() );

        // Remove some players from the Game
        Game.removePlayer(p4);
        Game.removePlayer(p5);
        System.out.println( "Number of players: " + Game.numberOfPlayers() );

        // Display players
        HashSet<Player> players = Game.getPlayers();
        for (Player player : players) {
            System.out.println(players);
        }
    }
}
