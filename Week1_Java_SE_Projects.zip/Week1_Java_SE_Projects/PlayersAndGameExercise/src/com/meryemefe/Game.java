package com.meryemefe;

import java.util.HashSet;

public class Game {
    private static HashSet<Player> players = new HashSet<>();

    public static void addPlayer( Player p){
        players.add( p);
    }

    public static void removePlayer( Player p){
        players.remove( p);
    }

    public static int numberOfPlayers(){
        return players.size();
    }

    public static HashSet<Player> getPlayers() {
        return players;
    }
}
