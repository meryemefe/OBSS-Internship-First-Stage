package com.meryemefe;

public class Main {

    public static void main(String[] args) {

        // Initialize a new number stack
        MyStack<Number> numberStack = new MyStack<>();

        // Try "push", "pop", "size" methods
        numberStack.push(1);
        numberStack.push(2);
        numberStack.push(3);
        numberStack.push(4);
        System.out.println("Stack content: " + numberStack);
        System.out.println( "Number of stack is " + numberStack.size() + ".\n");

        numberStack.pop();
        System.out.println("Stack content: " + numberStack + "\n");

        numberStack.push(2.8);
        numberStack.push(3.67f);
        System.out.println("Stack content: " + numberStack);

    }
}
