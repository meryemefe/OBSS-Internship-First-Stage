package com.meryemefe;

public interface Listable <E extends Number> {
    void push( E e);
    E pop();
}
