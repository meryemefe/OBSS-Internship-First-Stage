package com.meryemefe;

import java.util.ArrayList;

public class MyStack<T extends Number> implements Listable<T> {

    private ArrayList<T> list;

    public MyStack() {
        list = new ArrayList<>();
    }

    @Override
    public void push(T t) {
        System.out.println("Number is pushed.");
        list.add(0, t);
    }

    @Override
    public T pop() {
        System.out.println("Number is popped.");
        return list.remove(0);
    }

    public T get( int index ) {
        return list.get( index);
    }

    public int size(){
        return list.size();
    }

    @Override
    public String toString() {
        return list.toString();
    }
}
