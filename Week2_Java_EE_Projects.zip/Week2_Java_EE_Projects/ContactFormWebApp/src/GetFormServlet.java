import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/*
This servlet gets the requests and redirect the proper methods.
If the request is 'Add Contact', it calls addContactForm.
If the request is 'Edit Contact', it calls editContactForm.
 */
@WebServlet("/GetFormServlet")
public class GetFormServlet extends HttpServlet {

    static final String ACTION_ADD_CONTACT = "Add Contact";
    static final String ACTION_EDIT_CONTACT = "Edit Contact";

    protected void addContactForm(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        // Set response headers
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");

        // Create HTML form
        PrintWriter writer = resp.getWriter();
        writer.append("<!DOCTYPE html>\r\n")
                .append("<html>\r\n")
                .append("   <head>\r\n")
                .append("	    <title>Add Contact</title>\r\n")
                .append("	</head>\r\n")
                .append("	<body>\r\n")
                .append("       <form action=\"PostFormServlet\" method=\"POST\">\r\n")
                .append("		    Enter your name: \r\n")
                .append("			<input type=\"text\" required name=\"name\" />\r\n")
                .append("		    <br><br><br>\r\n")
                .append("		    Enter your phone number: \r\n")
                .append("			<input type=\"tel\" required name=\"tel_number\" />\r\n")
                .append("			<input type=\"submit\" name=\"action\" value=" + ACTION_ADD_CONTACT + " />\r\n")
                .append("	    </form>\r\n")
                .append("	</body>\r\n")
                .append("</html>\r\n");
    }

    protected void editContactForm(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        // Set response headers
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");

        // Create HTML form
        PrintWriter writer = resp.getWriter();
        writer.append("<!DOCTYPE html>\r\n")
                .append("<html>\r\n")
                .append("   <head>\r\n")
                .append("	    <title>Edit Contact</title>\r\n")
                .append("	</head>\r\n")
                .append("	<body>\r\n")
                .append("       <form action=\"PostFormServlet\" method=\"POST\">\r\n")
                .append("		    Enter your name: \r\n")
                .append("			<input type=\"text\" required name=\"name\" />\r\n")
                .append("		    <br><br><br>\r\n")
                .append("		    Enter your phone number: \r\n")
                .append("			<input type=\"tel\" required name=\"tel_number\" />\r\n")
                .append("			<input type=\"submit\" name=\"action\" value=" + ACTION_EDIT_CONTACT + " />\r\n")
                .append("	    </form>\r\n")
                .append("	</body>\r\n")
                .append("</html>\r\n");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");

        if( action.equals(ACTION_ADD_CONTACT)){
            addContactForm(req, resp);
        } else if( action.equals(ACTION_EDIT_CONTACT)) {
            editContactForm(req, resp);
        }
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
