import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
This servlet gets the post requests and redirect the proper methods.
If the request is 'Add Contact', it calls addContact and add values to the database.
If the request is 'Edit Contact', it calls editContact and edit values in the database.
 */
@WebServlet("/PostFormServlet")
public class PostFormServlet extends HttpServlet {
    static final String DB_URL = "jdbc:mysql://localhost:3306/jdbc_schema?serverTimezone=UTC";
    static final String DB_USERNAME = "root";
    static final String DB_PASSWORD = "meryemefe243";
    static final String ACTION_ADD_CONTACT = "Add";
    static final String ACTION_EDIT_CONTACT = "Edit";

    protected void addContact(HttpServletRequest req, HttpServletResponse resp, String name, String tel_number) throws ServletException, IOException {

        // Using "try with resources", add values to database
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            try( Connection connection = DriverManager.getConnection( DB_URL, DB_USERNAME, DB_PASSWORD) ){
                String query = "insert into contacts values ('" + name + "','" + tel_number + "')" ;
                try( PreparedStatement pstmt = connection.prepareStatement(query) ){
                    pstmt.executeUpdate();
                }
            }
        } catch(ClassNotFoundException | SQLException ex) {
            Logger.getLogger(PostFormServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        PrintWriter out = resp.getWriter();
        resp.setContentType("text/html");
        out.println("<script type=\"text/javascript\">");
        out.println("alert('Contact info is successfully added!');");
        out.println("</script>");

        resp.sendRedirect("index.jsp");
    }

    protected void editContact(HttpServletRequest req, HttpServletResponse resp, String name, String tel_number) throws ServletException, IOException {

        // Using "try with resources", add values to database
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            try( Connection connection = DriverManager.getConnection( DB_URL, DB_USERNAME, DB_PASSWORD) ){
                try( Statement pstmt = connection.createStatement() ){
                    try (ResultSet rs = pstmt.executeQuery("select * from contacts where name='"+ name + "'");) {
                        while(rs.next()) {
                            String query = "update contacts set tel_number='" + tel_number+ "' where name='" + name + "' " ;
                            pstmt.executeUpdate(query);
                        }
                    }
                }
            }
        } catch(ClassNotFoundException | SQLException ex) {
            Logger.getLogger(PostFormServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        PrintWriter out = resp.getWriter();
        resp.setContentType("text/html");
        out.println("<script type=\"text/javascript\">");
        out.println("alert('Contact info is successfully edited!');");
        out.println("</script>");

        resp.sendRedirect("index.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        // Get parameter from HTML form
        String name = req.getParameter("name");
        String tel_number = req.getParameter("tel_number");
        String action = req.getParameter("action");

        if( action.equals(ACTION_ADD_CONTACT)){
            addContact(req, resp, name, tel_number);
        } else if( action.equals(ACTION_EDIT_CONTACT)) {
            editContact(req, resp, name, tel_number);
        }

    }
}
