import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


// This servlet gets the request and returns 403 error if request url contains "secured".
// The following part is commented so that it will not to prevent working of other classes
//@WebServlet(value = "/*", loadOnStartup = 1)
public class ErrorServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = req.getRequestURL().toString().toLowerCase();

        if( url.contains("secured")){
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        resp.getWriter().print("Error is handled!");
    }
}
