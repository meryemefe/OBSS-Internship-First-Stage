import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/*
This is the first servlet.
Here, doPost, doGet, and service methods are examined.
Inside doGet method, an html form which asks username is created.
Inside doPost method, this posted username is printed.
 */
@WebServlet(value = "/homepage", loadOnStartup = 2)
public class FirstServlet extends HttpServlet {

    private static final String METHOD_GET = "GET";

    @Override
    public void init() throws ServletException {
        super.init();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        // Set response headers
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");

        // Create HTML form
        PrintWriter writer = resp.getWriter();
        writer.append("<!DOCTYPE html>\r\n")
                .append("<html>\r\n")
                .append("   <head>\r\n")
                .append("	    <title>Form input</title>\r\n")
                .append("	</head>\r\n")
                .append("	<body>\r\n")
                .append("       <form action=\"\" method=\"POST\">\r\n")
                .append("		    Enter your name: \r\n")
                .append("			<input type=\"text\" name=\"username\" />\r\n")
                .append("			<input type=\"submit\" value=\"Submit\" />\r\n")
                .append("	    </form>\r\n")
                .append("	</body>\r\n");

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Get parameter from HTML form
        String username = req.getParameter("username");

        // Set response headers
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");

        // Create HTML response
        PrintWriter writer = resp.getWriter();
        writer.append("<!DOCTYPE html>\r\n")
                .append("<html>\r\n")
                .append("   <head>\r\n")
                .append("       <title>Welcome message</title>\r\n")
                .append("	</head>\r\n")
                .append("	<body>\r\n");
        if (username != null && !username.trim().isEmpty()) {
            writer.append("	Welcome " + username + "!\r\n");
        } else {
            writer.append("	You did not enter a name!\r\n");
        }
        writer.append("     </body>\r\n")
                .append("</html>\r\n");

    }


    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String method = req.getMethod();
        if( method.equals(METHOD_GET) ){
            doGet( req, resp);
        } else {
            doPost(req, resp);
        }

      /*
        // The aim of this part is to examine which method is easier.
        // Coding HTML in .jsp file is absolutely easier than coding HTML inside servlet
        // Set response headers
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");

        // Create HTML form
        PrintWriter writer = resp.getWriter();
        writer.append("<!DOCTYPE html>\r\n")
                .append("<html>\r\n")
                .append("   <head>\r\n")
                .append("	    <title>Hello World</title>\r\n")
                .append("	</head>\r\n")
                .append("	<body>\r\n")
                .append("   <table BORDER ALIGN=\"center\" BGCOLOR=\"red\">")
                .append("       <TR height=\"200\">")
                .append("           <TD width=\"150\">")
                .append("               <span style=\"font-family: Tahoma; font-size: large; align-content: center; color: white; \">Hello World</span><br />")
                .append("           </TD>")
                .append("       </TR>")
                .append("   </table>")
                .append("	</body>\r\n");
        resp.sendRedirect("secondJsp.jsp");
       */
    }

    @Override
    public void destroy() {
        super.destroy();
    }
}