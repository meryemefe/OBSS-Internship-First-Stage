import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter(filterName = "AuthenticationFilter", urlPatterns = {"/private/*"})
public class AuthenticationFilter implements Filter {

    static final String LOGIN_URL = "../public/login.jsp";

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        if (servletRequest instanceof HttpServletRequest) {

            HttpSession session = ((HttpServletRequest) servletRequest).getSession(false);

            if( session != null){
                String username = (String) session.getAttribute(USER_INFO.USERNAME.toString());

                if( username == null){
                    servletRequest.getRequestDispatcher(LOGIN_URL).forward(servletRequest, servletResponse);
                    return;
                } else {
                    filterChain.doFilter(servletRequest, servletResponse);
                    return;
                }
            } else {
                ((HttpServletResponse)servletResponse).sendRedirect(LOGIN_URL);
                return;
            }
        }
    }

    @Override
    public void destroy() {
    }
}
