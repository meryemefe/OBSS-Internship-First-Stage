import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/login-servlet")
public class LoginServlet extends HttpServlet {

    static final String DB_URL = "jdbc:mysql://localhost:3306/jdbc_schema?serverTimezone=UTC";
    static final String DB_USERNAME = "root";
    static final String DB_PASSWORD = "meryemefe243";

    /*
    This method checks database to see whether user is registered to database or not.
    It returns true, if user is registered.
    Otherwise, it returns false.
     */
    protected boolean isUserRegistered( HttpServletRequest req, HttpServletResponse resp, String username, String password) throws IOException {
        // Using "try with resources", check whether user is registered to database
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            try( Connection connection = DriverManager.getConnection( DB_URL, DB_USERNAME, DB_PASSWORD) ){
                try( Statement stmt = connection.createStatement() ){
                    try (ResultSet rs = stmt.executeQuery("select * from user where username='"+ username + "' and password='" + password + "'");) {
                        return rs.next();
                    }
                }
            }
        } catch(ClassNotFoundException | SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }


    /*
    This method checks database to see whether user is registered to database or not by using isUserRegistered() method.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Get parameter from HTML form
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        boolean userRegistered = isUserRegistered( req, resp, username, password);

        if( userRegistered ){
            // Create session if it has not been started yet
            HttpSession session=req.getSession(true);

            // Add attributes to the session
            session.setAttribute(USER_INFO.USERNAME.toString(), username);

            req.getRequestDispatcher("/private/secured.jsp").forward(req, resp);
            return;
        }

        req.getRequestDispatcher("/public/public.html").forward(req, resp);
    }
}