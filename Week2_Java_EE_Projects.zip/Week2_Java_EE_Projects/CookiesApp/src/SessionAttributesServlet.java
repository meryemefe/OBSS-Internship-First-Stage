import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

/*
This servlet prints all the attributes and id of the current session.
 */
@WebServlet("/list-session-attributes")
public class SessionAttributesServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try{

            resp.setContentType("text/html");
            PrintWriter out = resp.getWriter();

            HttpSession session=req.getSession();

            /*
            // This is the first approach to get session attributes.
            // However, if we need all attributes, this approach is inefficient.
            String username = (String)session.getAttribute("Username");
            String birth = (String) session.getAttribute("Birth");
            String location = (String) session.getAttribute("Location");
            Integer age = (Integer) session.getAttribute("Age");
            */

            out.print("SESSION ID: ");
            out.print( session.getId() );
            out.print( "<br><br>");

            out.print("SESSION ATTRIBUTES: ");
            out.print( "<br><br>");

            // Get all attributes' names and values by using enumeration
            Enumeration<String> attributes = session.getAttributeNames();
            while (attributes.hasMoreElements()) {
                String attribute = attributes.nextElement();
                out.print( attribute+" : " + session.getAttribute(attribute));
                out.print( "<br>");
            }

            out.print("<br><br><a href='index.jsp'>Click to go to index!</a>");
            out.print("<br><br><a href=\"create-session\">Click here to create session!</a>");
            out.print("<br><br><a href='invalidate-session'>Click to call session invalidate!</a>");
            out.close();

        }catch(Exception e){System.out.println(e);}
    }
}
