import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

/*
This servlet invokes invalidate() method.
 */
@WebServlet("/invalidate-session")
public class InvalidateSessionServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        session.invalidate();

        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        out.print("<br><br><a href='index.jsp'>Click to go to index!</a>");
        out.print("<br><br><a href=\"create-session\">Click here to create session!</a>");
        out.print("<br><br><a href='list-session-attributes'>Click to see session attributes!</a>");
        out.close();

    }
}
