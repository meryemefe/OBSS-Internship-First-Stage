import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

/*
This servlet creates a session.
 Also, it sets a couple of attributes.
 */
@WebServlet("/create-session")
public class CreateSessionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        try{
            resp.setContentType("text/html");
            PrintWriter out = resp.getWriter();

            // Create session if it has not been started yet
            HttpSession session=req.getSession(true);

            // Add attributes to the session
            session.setAttribute("Username","Meryem");
            session.setAttribute("Birth","Kayseri");
            session.setAttribute("Location","Ankara");
            session.setAttribute("Age", 22);

            out.print("<br><br><a href='index.jsp'>Click to go to index!</a>");
            out.print("<br><br><a href='list-session-attributes'>Click to see session attributes!</a>");
            out.print("<br><br><a href='invalidate-session'>Click to call session invalidate!</a>");
            out.close();

        }catch(Exception e){System.out.println(e);}

    }
}

